% -*- Mode:Prolog -*-
% sssp.pl

%---------%---------%---------%---------%---------%---------%---------%
% SINGLE SOURCE SHORTEST PATHS %


% Progetto a cura di:

% Papa Emanuele
% Luca Santambrogio


%---------%---------%---------%---------%---------%---------%---------%
% DICHIARAZIONI INIZIALI %


%:- set_prolog_flag(autoload, false).

:- use_module(library(heaps), []).
% except([heap_size/2])

:- use_module(library(ugraphs), []).
% except([vertices/2, neighbors/3])

% SWI PROLOG 7.2.0 -> inf/0 not defined
%:- use_module(library(arithmetic)).

:- dynamic graph/1.
:- dynamic vertex/2.
:- dynamic arc/4.

:- dynamic dist/3.
:- dynamic visited/2.
:- dynamic previous/3.

:- dynamic heap/2.
:- dynamic heap_entry/4.

%:- dynamic heap_size/2.
%:- dynamic vertices/2.
%:- dynamic neighbors/3.


%---------%---------%---------%---------%---------%---------%---------%
% ESEMPI %


% test preso dalla pagina wikipedia
test_1(G) :-
    new_graph(G),
    new_vertex(G, source),
    new_vertex(G, a),
    new_vertex(G, b),
    new_vertex(G, c),
    new_vertex(G, d),
    new_vertex(G, e),
    new_vertex(G, final),
    new_arc(G, a, b, 6),
    new_arc(G, source, a, 2),
    new_arc(G, source, d, 8),
    new_arc(G, a, c, 2),
    new_arc(G, d, c, 2),
    new_arc(G, d, e, 3),
    new_arc(G, c, e, 9),
    new_arc(G, e, final, 1),
    new_arc(G, b, final, 5),
    list_graph(G).

%test inventato a 9 nodi
test_2(G) :-
    new_graph(G),
    new_vertex(G, a),
    new_vertex(G, b),
    new_vertex(G, c),
    new_vertex(G, d),
    new_vertex(G, e),
    new_vertex(G, f),
    new_vertex(G, g),
    new_vertex(G, h),
    new_vertex(G, i),
    new_arc(G, a, b, 1),
    new_arc(G, b, c, 4),
    new_arc(G, d, e, 2),
    new_arc(G, e, f, 5),
    new_arc(G, g, h, 2),
    new_arc(G, h, i, 8),
    new_arc(G, a, d, 3),
    new_arc(G, d, g, 9),
    new_arc(G, b, e, 4),
    new_arc(G, e, h, 9),
    new_arc(G, c, f, 6),
    new_arc(G, f, i, 50),
    new_arc(G, b, d, 12),
    new_arc(G, d, h, 15),
    new_arc(G, h, f, 32),
    new_arc(G, f, b, 7).

% test per funzionamento predicati heap
% insert/extract/modify_key
test_heap(H) :-
    new_heap(H),
    insert(H, 12, a),
    insert(H, 7, b),
    insert(H, 50, c),
    insert(H, 12, d),
    insert(H, 4, e),
    insert(H, 6, f),
    list_heap(H).
    %delete_heap(H).


%---------%---------%---------%---------%---------%---------%---------%
% INTERFACCIA PROLOG PER LA MANIPOLAZIONE DEI GRAFI %


new_graph(G) :-
    graph(G), !.

new_graph(G) :-
    assert(graph(G)), !.


delete_graph(G) :-
    graph(G),
    retractall(graph(G)),
    retractall(vertex(G, _)),
    retractall(arc(G, _, _, _)), !.

delete_graph(_) :-
    writef("Not valid data.").


list_graph(G) :-
    graph(G),
    list_vertices(G),
    list_arcs(G), !.

list_graph(_) :-
    writef("Not valid data.").


new_vertex(G, V) :-
    graph(G),
    vertex(G, V), !.

new_vertex(G, V) :-
    graph(G),
    assert(vertex(G, V)), !.

new_vertex(_, _) :-
    writef("Not valid data.").


:- abolish(vertices/2).
vertices(G, Vs) :-
    graph(G),
    findall(V, vertex(G, V), Vs), !.

vertices(_, _) :-
    writef("Not valid data.").


list_vertices(G) :-
    graph(G),
    listing(vertex(G, _)), !.

list_vertices(_) :-
    writef("Not valid data.").


new_arc(G, U, V) :-
    graph(G),
    vertex(G, U),
    vertex(V, U),
    new_arc(G, U, V, 1), !.

new_arc(G, U, V, Weight) :-
    graph(G),
    vertex(G, U),
    vertex(G, V),
    arc(G, U, V, Weight), !.


new_arc(G, U, V, Weight) :-
    graph(G),
    vertex(G, U),
    vertex(G, V),
    assert(arc(G, U, V, Weight)), !.

new_arc(_, _, _, _) :-
    writef("Not valid data.").


arcs(G, Es) :-
    graph(G),
    findall(arc(G, U, V, W), arc(G, U, V, W), Es), !.

arcs(_, _) :-
    writef("Not valid data.").


list_arcs(G) :-
    graph(G),
    listing(arc(G, _, _, _)), !.

list_arcs(_) :-
    writef("Not valid data.").


neighbors(G, V, Ns) :-
    graph(G),
    vertex(G, V),
    findall(arc(G, V, N, W), arc(G, V, N, W), Ns1),
    findall(arc(G, N, V, W), arc(G, N, V, W), Ns2),
    append(Ns1, Ns2, Ns), !.

neighbors(_, _, _) :-
    writef("Not valid data.").


vertex_neighbors(G, V, VNs) :-
    graph(G),
    vertex(G, V),
    findall(N, arc(G, V, N, W), Ns1),
    findall(N, arc(G, N, V, W), Ns2),
    append(Ns1, Ns2, Ns),
    findall(T, visited(G, T), Ts),
    remove_from_list(Ns, Ts, VNs).


remove_from_list(Vs1, [], Vs1) :- !.

remove_from_list(Vs1, Vs2, Vs) :-
    Vs2 = [T | Ts],
    member(T, Vs1),
    delete(Vs1, T, Us),
    remove_from_list(Us, Ts, Vs), !.

remove_from_list(Vs1, Vs2, Vs) :-
    Vs2 = [_ | Ts],
    remove_from_list(Vs1, Ts, Vs), !.


%---------%---------%---------%---------%---------%---------%---------%
% SSSP IN PROLOG %


dist(G, V, D) :-
    graph(G),
    vertex(G, V),
    number(D), !.

dist(_, _, _) :-
    writef("Not valid data.").


%list_dist(G) :- listing(dist(G, _, _)).


delete_dist(G) :-
    retractall(dist(G, _, _)).


visited(G, V) :-
    graph(G),
    vertex(G, V), !.

visited(_, _) :-
    writef("Not valid data.").


%list_visited(G) :- listing(visited(G, _)).


delete_visited(G) :-
    retractall(visited(G, _)).


previous(G, V, U) :-
    graph(G),
    vertex(G, V),
    vertex(G, U), !.

previous(_, _, _) :-
    writef("Not valid data.").


%list_previous(G) :- listing(previous(G, _, _)).


delete_previous(G) :-
    retractall(previous(G, _, _)).


change_dist(G, V, NewDist) :-
    graph(G),
    vertex(G, V),
    retractall(dist(G, V, _)),
    assert(dist(G, V, NewDist)), !.

change_dist(_, _, _) :-
    writef("Not valid data.").


change_previous(G, V, U) :-
    graph(G),
    vertex(G, V),
    vertex(G, U),
    retractall(previous(G, V, _)),
    assert(previous(G, V, U)), !.

change_previous(_, _, _) :-
    writef("Not valid data.").


sssp(G, Source) :-
    graph(G),
    vertex(G, Source),
    dijkstra(G, Source).

sssp(_, _) :-
    writef("Not valid data.").


dijkstra(G, Source) :-
    new_heap(G),
    % S <- vuoto
    delete_dist(G),
    delete_visited(G),
    delete_previous(G),
    % Q <- vertices(G)
    vertices(G, Vs),
    % initialize-single-source
    initialize_single_source(G, Source, Vs),
    % while Q non vuoto
    internal_dijkstra(G, Vs),
    delete_heap(G).


internal_dijkstra(_, []) :- !.

internal_dijkstra(G, Vs) :-
    % do u <- extract-min(Q)
    head(G, HK, HV),
    delete(Vs, HV, Ts),
    %Vs = [HV | Ts],
    extract(G, HK, HV),
    % S <- S U {u}
    assert(visited(G, HV)),
    %for each vertex v E Adj[v]
    vertex_neighbors(G, HV, Ns),
    %do relax(u, v, w)
    relax(G, HV, Ns),
    internal_dijkstra(G, Ts), !.


relax(_, _, []) :- !.

relax(G, V, Ns) :-
    Ns = [T | Ts],
    dist(G, V, DV),
    dist(G, T, DN),
    arc(G, V, T, W),
    DN =< DV + W,
    relax(G, V, Ts), !.

relax(G, V, Ns) :-
    Ns = [T | Ts],
    dist(G, V, DV),
    dist(G, T, DN),
    arc(G, T, V, W),
    DN =< DV + W,
    relax(G, V, Ts), !.

relax(G, V, Ns) :-
    Ns = [T | Ts],
    dist(G, V, DV),
    arc(G, V, T, W),
    NewDist is DV + W,
    change_dist(G, T, NewDist),
    change_previous(G, T, V),
    heap_entry(G, _, OldKey, T),
    modify_key(G, NewDist, OldKey, T),
    relax(G, V, Ts), !.

relax(G, V, Ns) :-
    Ns = [T | Ts],
    dist(G, V, DV),
    arc(G, T, V, W),
    NewDist is DV + W,
    change_dist(G, T, NewDist),
    change_previous(G, T, V),
    heap_entry(G, _, OldKey, T),
    modify_key(G, NewDist, OldKey, T),
    relax(G, V, Ts), !.


initialize_single_source(_, _, []) :- !.

initialize_single_source(G, Source, Vs) :-
    Vs = [Source | Ts],
    vertex(G, Source),
    assert(dist(G, Source, 0)),
    insert(G, 0, Source),
    initialize_single_source(G, Source, Ts), !.

initialize_single_source(G, Source, Vs) :-
    Vs = [T | Ts],
    assert(dist(G, T, inf)),
    assert(previous(G, T, not_defined)),
    insert(G, inf, T),
    initialize_single_source(G, Source, Ts), !.


shortest_path(G, Source, V, Path) :-
    graph(G),
    vertex(G, Source),
    vertex(G, V),
    sssp(G, Source),
    path_list(G, Source, V, Path), !.

shortest_path(_, _, _, _) :-
    writef("Not valid data.").


path_list(G, Source, V, Ps) :-
    previous(G, V, Source),
    arc(G, Source, V, W),
    Ps = [arc(G, Source, V, W)], !.

path_list(G, Source, V, Ps) :-
    previous(G, V, Source),
    arc(G, V, Source, W),
    Ps = [arc(G, Source, V, W)], !.

path_list(G, Source, V, Ps) :-
    previous(G, V, U),
    arc(G, U, V, W),
    path_list(G, Source, U, Ps1),
    append(Ps1, [arc(G, U, V, W)], Ps), !.

path_list(G, Source, V, Ps) :-
    previous(G, V, U),
    arc(G, V, U, W),
    path_list(G, Source, U, Ps1),
    append(Ps1, [arc(G, U, V, W)], Ps), !.

path_list(_, Source, V, _) :-
    writef("Path does not exist from %w to %w.", [Source, V]), !.


%---------%---------%---------%---------%---------%---------%---------%
% MINHEAP IN PROLOG %


new_heap(H) :-
    heap(H, _), !.

new_heap(H) :-
    assert(heap(H, 0)), !.

new_heap(_) :-
    writef("Not valid data.").


delete_heap(H) :-
    retract(heap(H, _)),
    retractall(heap_entry(H, _, _, _)), !.

delete_heap(_) :-
    writef("Not valid data.").


:-abolish(heap_size/2).
heap_size(H, S) :-
    heap(H, S), !.

heap_size(_, _) :-
    writef("Not valid data.").


empty(H) :-
    heap(H, 0), !.

empty(_) :-
    writef("Not valid data.").


not_empty(H) :-
    heap(H, _),
    heap_size(H, Size),
    Size > 0, !.

not_empty(_) :-
    writef("Not valid data.").


head(H, K, V) :-
    heap(H, _),
    not_empty(H),
    heap_entry(H, 1, K, V), !.

head(_, _, _) :-
    writef("Not valid data.").


insert(H, K, V) :-
    heap(H, _),
    empty(H),
    change_size(H, 1),
    assert(heap_entry(H, 1, K, V)), !.

insert(H, K, V) :-
    heap(H, _),
    heap_size(H, Size),
    NewSize is Size + 1,
    father(PF, NewSize),
    heap_entry(H, PF, KF, _),
    KF =< K,
    change_size(H, 1),
    assert(heap_entry(H, NewSize, K, V)), !.

insert(H, K, V) :-
    heap(H, _),
    change_size(H, 1),
    heap_size(H, Size),
    assert(heap_entry(H, Size, K, V)),
    go_up(H, Size), !.

insert(_, _, _) :-
    writef("Not valid data.").


go_up(_, 1) :- !.

go_up(H, PC) :-
    heap_entry(H, PC, KC, _),
    father(PF, PC),
    heap_entry(H, PF, KF, _),
    KF =< KC, !.

go_up(H, PC) :-
    heap_entry(H, PC, _, _),
    father(PF, PC),
    swap(H, PF, PC),
    go_up(H, PF), !.


extract(H, _, _) :-
    heap(H, _),
    heap(H, Size),
    Size < 1, !.

extract(H, K, V) :-
    heap(H, _),
    heap_entry(H, _, K, V),
    heap_size(H, 1),
    change_size(H, -1),
    retract(heap_entry(H, _, K, V)), !.

extract(H, K, V) :-
    heap(H, _),
    heap_entry(H, _, K, V),
    heap_size(H, Size),
    change_size(H, -1),
    retract(heap_entry(H, P, K, V)),
    retract(heap_entry(H, Size, K1, V1)),
    assert(heap_entry(H, P, K1, V1)),
    go_up(H, P),
    heapify(H, 1), !.

extract(_, _, _) :-
    writef("Not valid data.").


% nodo foglia
heapify(H, PF) :-
    heap_entry(H, PF, _, _),
    heap_size(H, Size),
    PC1 is PF * 2,
    PC1 > Size, !.

% figlio unico - figlio >= padre
heapify(H, PF) :-
    heap_entry(H, PF, KF, _),
    heap_size(H, Size),
    PC1 is PF * 2,
    PC1 = Size,
    heap_entry(H, PC1, KC1, _),
    KC1 >= KF, !.

% singolo figlio - figlio < padre
heapify(H, PF) :-
    heap_entry(H, PF, KF, _),
    heap_size(H, Size),
    PC1 is PF * 2,
    PC1 = Size,
    heap_entry(H, PC1, KC1, _),
    KC1 < KF,
    swap(H, PF, PC1),
    heapify(H, PC1), !.

% due figli - figli >= padre
heapify(H, PF) :-
    heap_entry(H, PF, KF, _),
    PC1 is PF * 2,
    heap_entry(H, PC1, KC1, _),
    KC1 >= KF,
    PC2 is PC1 + 1,
    heap_entry(H, PC2, KC2, _),
    KC2 >= KF, !.

% due figli - figlio 1 >= padre e figlio 2 < padre
heapify(H, PF) :-
    heap_entry(H, PF, KF, _),
    PC1 is PF * 2,
    heap_entry(H, PC1, KC1, _),
    KC1 >= KF,
    PC2 is PC1 + 1,
    heap_entry(H, PC2, KC2, _),
    KC2 < KF,
    swap(H, PF, PC2),
    heapify(H, PC2), !.

% due figli - figlio 1 < padre e figlio 2 >= padre
heapify(H, PF) :-
    heap_entry(H, PF, KF, _),
    PC1 is PF * 2,
    heap_entry(H, PC1, KC1, _),
    KC1 < KF,
    PC2 is PC1 + 1,
    heap_entry(H, PC2, KC2, _),
    KC2 >= KF,
    swap(H, PF, PC1),
    heapify(H, PC1), !.

% due figli - figlio 1 < padre e figlio 2 < padre (figlio 1 =< figlio 2)
heapify(H, PF) :-
    heap_entry(H, PF, KF, _),
    PC1 is PF * 2,
    heap_entry(H, PC1, KC1, _),
    KC1 < KF,
    PC2 is PC1 + 1,
    heap_entry(H, PC2, KC2, _),
    KC2 < KF,
    KC1 =< KC2,
    swap(H, PF, PC1),
    heapify(H, PC1), !.

 % due figli - figlio 1 < padre e figlio 2 < padre (figlio 2 < figlio 1)
heapify(H, PF) :-
    heap_entry(H, PF, KF, _),
    PC1 is PF * 2,
    heap_entry(H, PC1, KC1, _),
    KC1 < KF,
    PC2 is PC1 + 1,
    heap_entry(H, PC2, KC2, _),
    KC2 < KF,
    KC1 > KC2,
    swap(H, PF, PC2),
    heapify(H, PC2), !.


swap(H, PF, PC) :-
    retract(heap_entry(H, PF, KF, VF)),
    retract(heap_entry(H, PC, KC, VC)),
    assert(heap_entry(H, PF, KC, VC)),
    assert(heap_entry(H, PC, KF, VF)).


modify_key(H, NewKey, OldKey, V) :-
    heap(H, _),
    heap_entry(H, _, OldKey, V),
    retract(heap_entry(H, P, OldKey, V)),
    assert(heap_entry(H, P, NewKey, V)),
    go_up(H, P),
    heapify(H, 1), !.

modify_key(_, _, _, _) :-
    writef("Not valid data.").


father(F, C) :-
    F is floor(C / 2).


change_size(H, A) :-
    heap(H, _),
    heap(H, OldSize),
    NewSize is OldSize + A,
    retract(heap(H, OldSize)),
    assert(heap(H, NewSize)).


list_heap(H) :-
    heap(H, _),
    heap_size(H, Size),
    ordering(H, Size),
    listing(heap_entry(H, _, _, _)), !.

list_heap(_) :-
    writef("Not valid data.").


ordering(_, 0) :- !.

ordering(H, Size) :-
    retract(heap_entry(H, Size, K, V)),
    asserta(heap_entry(H, Size, K, V)),
    S is Size - 1,
    ordering(H, S), !.


%---------%---------%---------%---------%---------%---------%---------%


% end of file -*- sssp.pl
