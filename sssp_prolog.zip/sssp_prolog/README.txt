% -*- Mode: Prolog -*-
% README.txt


%---------%---------%---------%---------%---------%---------%---------%
% INTRODUZIONE %

Nome progetto: sssp.pl

Obbiettivo: Calcolare il percorso più breve da un punto ad un altro in un grafo
connesso con distanze tra nodi non negative.
L'implementazione è stata effettuata usando l'algoritmo di Dijkstra.
Inoltre, il progetto è stato realizzato in modo tale che l'algoritmo funzioni
anche su grafi non orientati.

Conoscenze necessarie per la comprensione del progetto:
Conoscenze base di programmazione in linguaggio Prolog
Conoscenze grafi, heap, heapsort
Algoritmo di Dijkstra


%---------%---------%---------%---------%---------%---------%---------%


Progetto scolastico livello universitario a cura di:

Papa Emanuele      
Santambrogio Luca  


%---------%---------%---------%---------%---------%---------%---------%


Linguaggio: SWI-Prolog 8.2.1
Potrebbe funzionare con altre versioni di Prolog successive alla 8.0 in quanto
in questa è stato implementata il predicato inf/0 che restituisce la 
rappresentazione di infinito positivo.
In caso di versioni precedenti si consiglia di sostituire il valore inf 
(presente solamente nel predicato initialize_single_source/3)  con un numero 
abbastanza grande. 


%---------%---------%---------%---------%---------%---------%---------%


Legenda:
La simbologia "%% Aggiunto da noi %%" prima di un predicato indica che quel 
predicato non era stato espressamente richiesto dal professore ma necessario 
per il funzionamento del tutto


%---------%---------%---------%---------%---------%---------%---------%


Spiegazione dei predicati utilizzati:


%---------%---------%---------%---------%---------%---------%---------%
% INTERFACCIA PROLOG PER LA MANIPOLAZIONE DEI GRAFI %


:- new_graph(G).
Questo predicato inserisce un nuovo grafo nella base-dati Prolog. 


:- delete_graph(G).
Rimuove tutto il grafo (vertici e archi inclusi) dalla base-dati Prolog.


:- new_vertex(G, V).
Aggiunge il vertice V nella base-dati Prolog. N.B. si richiede che il predicato
che rappresenta i vertici, da aggiungere alla base-dati Prolog, sia 
vertex(G, V). 


:- vertices (G, Vs).
Questo predicato è vero quando Vs è una lista contenente tutti i vertici di G.
Nell'implementazione di questo predicato abbiamo dovuto aggiungere il predicato 
abolish/1 in quanto vertices/2 esisteva già nella libreria ugraph di Prolog, 
creando notevoli problemi. 


:- list_vertices(G).
Questo predicato stampa alla console dell’interprete Prolog una lista dei 
vertici del grafo G (usate listing/1).


:- new_arc(G, U, V, Weight).
Aggiunge un arco del grafo G alla base dati Prolog. N.B. è richiesto che il 
predicato che rappresenta gli archi, da aggiungere alla base-dati Prolog, 
sia arc(G, U, V, Weight). Per comodità potete anche costruire una versione 
new_arc/3 così definita: new_arc(G, U, V) :- new_arc(G, U, V, 1).


:- arcs(G, Es).
Questo predicato è vero quando Es è una lista di tutti gli archi presenti in G.


:- neighbors(G, V, Ns).
Questo predicato è vero quando V è un vertice di G e Ns è una lista contenente
gli archi, arc(G, V, N, W) e arc(G, N, V, W), che portano ai vertici N
immediatamente raggiungibili da V .


:- list_arcs(G).
Questo predicato stampa alla console dell’interprete Prolog una lista degli 
archi del grafo G (è il simmetrico di list_vertices/1).


:- list_graph(G).
Questo predicato stampa alla console dell’interprete Prolog una lista dei 
vertici e degli archi del grafo G.


:- vertex_neighbors(G, V, VNs).
Questo predicato controlla se G è un grafo e se V è un vertice di G, inserisce
un una lista tutti i vertici "vicini" a V, e poi da questa lista rimuove i 
vertici già visitati 
(quindi con distanza già calcolata e minima dalla sorgente).


%% Aggiunto da noi %%
:- remove_from_list(Vs1, Vs2, Vs).
Questo predicato rimuove gli elementi della lista Vs2 dalla lista Vs1, 
e restituisce il tutto in Vs.


%---------%---------%---------%---------%---------%---------%---------%
% MINHEAP IN PROLOG %

Un MINHEAP è una struttura dati che prevede le sequenti operazioni: 
NEWHEAP, INSERT, HEAD, EXTRACT, MODIFYKEY. 


:- new_heap(H).
Questo predicato inserisce un nuovo heap nella base-dati Prolog.
Notate che il predicato heap(H, S) mantiene la dimensione corrente dello heap
nel secondo argomento.


:- delete_heap(H).
Rimuove tutto lo heap (incluse tutte le “entries”) dalla base-dati Prolog.


:- heap_size(H, S).
Questo predicato è vero quanto S è la dimensione corrente dello heap. 
Nell'implementazione di questo predicato abbiamo dovuto aggiungere il predicato
abolish/1 in quanto heaps_size/2 esisteva già nella libreria heaps di Prolog, 
creando notevoli problemi. 


:- empty(H).
Questo predicato è vero quando lo heap H non contiene elementi.


:- not_empty(H).
Questo predicato è vero quando lo heap H contiene almeno un elemento.


:- head(H, K, V).
Il predicato head/3 è vero quando l’elemento dello heap H con 
chiave minima K è V.


:- insert(H, K, V).
Il predicato insert/3 è vero quando l’elemento V è inserito nello heap H 
con chiave K.
Naturalmente, lo heap H dovrà essere ristrutturato in modo da mantenere 
la "heap property" per ogni nodo.


:- extract(H, K, V).
Il predicato extract/3 è vero quando la coppia K, V con K minima, è rimossa
dallo heap H.
Naturalmente, lo heap H dovrà essere ristrutturato in modo da mantenere 
la “heap property” per ogni nodo.


:- modify_key(H, NewKey, OldKey, V).
Il predicato modify_key/4 è vero quando la chiave OldKey 
(associata al valore V) è sostituita da NewKey.


:- list_heap(H).
Il predicato richiama listing/1 per stampare sulla console Prolog lo stato
interno dello heap.


%% Aggiunto da noi %%
:- father(F, C).
Il predicato controlla se F è genitore di C.


%% Aggiunto da noi %%
:- go_up(H, PC).
questo predicato viene utilizzato da insert/3 e modify_key/4 per aggiornare 
lo stato dello heap in modo da rispettare la heap property dopo che una entry
è stata aggiunta o modificata.


%% Aggiunto da noi %%
:- ordering(H, Size).
Questo predicato serve al predicato list_heap/1 per stampare in ordine 
(dalla prima posizione all'ultima) le entry dello heap. 


%% Aggiunto da noi %%
:- heapify(H, PF).
Questo predicato riordina le entry dello heap facendo in modo di rispettare 
la "heap property".


%% Aggiunto da noi %%
:- swap(H, PF, PC).
Questo predicato scambia la posizione nello heap di due entry.


%---------%---------%---------%---------%---------%---------%---------%
% SSSP IN PROLOG %


:- dist(G, V, D).
Questo predicato è vero quando V è un vertice di G e, durante e dopo
l’esecuzione dell’algoritmo di Dijkstra, la distanza minima del vertice V
dalla “sorgente” è D.


:- visited(G, V).
Questo predicato è vero quando V è un vertice di G e, durante e dopo 
l’esecuzione dell’algoritmo di Dijkstra, V risulta “visitato”.


:- previous(G, V, U).
Questo predicato è vero quando V ed U sono vertici di G e, durante e dopo 
l’esecuzione dell’algoritmo di Dijkstra, il vertice U è il vertice “precedente”
a V nel cammino minimo dalla “sorgente” a V.


:- change_dist(G, V, NewDist).
Questo predicato ha sempre successo con due effetti collaterali: prima tutte 
le istanze di dist(G, V, _) sono ritirate dalla base-dati Prolog, e quindi 
dist(G, V, NewDist) è asserita.


:- change_previous(G, V, U).
Questo predicato ha successo con due effetti collaterali: prima tutte le 
istanze di previous(G, V, _) sono ritirate dalla base-dati Prolog, e quindi
previous(G, V, U) è asserita.


:- sssp(G, Source).
Questo predicato ha successo con un effetto collaterale. Dopo la sua prova, 
la base-dati Prolog ha al suo interno i predicati dist(G, V, D) per ogni V 
appartenente a G; la base-dati Prolog contiene anche i predicati 
previous(G, V, U) e visited(V) per ogni V, ottenuti durante le iterazioni 
dell’algoritmo di Dijkstra.


:- shortest_path(G, Source, V, Path).
Questo predicato è vero quando Path è una lista di archi
 [arc(G, Source, N1, W1),
  arc(G, N1, N2, W2),
  …,
  arc(G, NK, V, WK)]
che rappresenta il “cammino minimo” da Source a V.


%% Aggiunto da noi %%
:- dijkstra(G, Source).
Questo predicato esegue le prime operazioni, necessarie per il funzionamento
dell'algoritmo di dijkstra tra le quali la creazione di liste e assegnamento 
di valori alle entry.


%% Aggiunto da noi %%
:- internal_dijkstra(G, Vs)
Questo predicato esegue effettivamente la parte operativa dell'algoritmo di 
dijkstra in maniera ricorsiva.
Calcolo della testa, cancellazione dallo heap, inserimento nella base dati 
dei "visited".


%% Aggiunto da noi %%
:- relax(G, V, Ns).
Questo predicato controlla se la distanza provvisoria del nodo dalla sorgente 
è minore rispetto alla somma tra vertice precedente e peso dell'arco arco ed 
asserta nella base dati la minore.


%% Aggiunto da noi %%
:- delete_dist(G).
Questo predicato cancella tutte le precedenti asserzioni di dist con grafo G 
presenti nella base dati, se presenti.


%% Aggiunto da noi %%
:- delete_visited(G).
Questo predicato cancella tutte le precedenti asserzioni di visited con grafo G
presenti nella base dati, se presenti.


%% Aggiunto da noi %%
:- delete_previous(G).
Questo predicato cancella tutte le precedenti asserzioni di previous con
grafo G presenti nella base dati, se presenti.


%% Aggiunto da noi %%
:- initialize_single_source(G, Source, Vs).
Questo predicato inserisce nella base dati in valori per il funzionamento 
dell'algoritmo di dijkstra. Esplicita quale sia il nodo sorgente e mette 
distanza 0; per tutti gi altri nodi invece asserta distanza infinita e 
il precedente ancora da definire.


%% Aggiunto da noi %%
:- path_list(G, Source, V, Ps).
Questo predicato va a inserire nella lista Ps la sequenza di archi che 
specificano il percorso con peso minimo del grafo G, sorgente Source e 
nodo finale V.


%---------%---------%---------%---------%---------%---------%---------%


Riflessioni post-progetto:

Sono stati aggiunti messaggi di errore ovunque l'utente possa sbagliare
a inserire i valori in input di una funzione.

L'intero elaborato è stato svolto affinchè il testo non superasse le 80
colonne secondo le direttive del prof (e così come il progetto, 
anche questo file rispetta tali norme).


%---------%---------%---------%---------%---------%---------%---------%


% Obi-Wan never told you what happend to your father?
% He told me enough! He told me you killed him!
% C... I'm your father - father(F, C)
(citazione abbastanza iconica: non c'è bisogno di dirvi quale sia
l'originale)


%---------%---------%---------%---------%---------%---------%---------%


end of file -*- README.txt